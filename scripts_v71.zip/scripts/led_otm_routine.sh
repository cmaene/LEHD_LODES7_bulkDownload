#!/bin/bash

cd /mnt/ide0/home/cmaene/data/LED_OTM
today=`date +"%m%d%y"`
echo $today

# ---------------------------------------------------------
# R - run LEHD_LODES71_bulkDownload.R
# ---------------------------------------------------------
# download LODES Version 7.1 data from Census Bureau

# ---------------------------------------------------------
# Bash - extract all compressed file within "Version71" directory
# ---------------------------------------------------------
# gunzip - is a bit rough tool, but..
# it will replace all files with name ends with .z or.Z (like my .gz files)
# -r Recurse: uncompress all files within the directory
# -k : keep the original file
# gunzip -rvk Version71

gunzip -rv Version71

# ---------------------------------------------------------
# Bash - reorganize files as follows
# ---------------------------------------------------------
# files were organized as follows because of irregular data availabilities by states
# i.e. keep organizing data files by state doesn't make much sense
# RAC -- JT00 -- 2002-2013 (yearly folder, containing all "_rac_" & "20xx.csv" files)
# WAC -- JT00 -- 2002-2013 (yearly folder, containing all "_rac_" & "20xx.csv" files)
# file name example: ak_rac_S000_JT00_2002.csv

mkdir /mnt/ide0/home/cmaene/data/LED_OTM/Version71wksp
cd /mnt/ide0/home/cmaene/data/LED_OTM/Version71wksp
mkdir RAC
cd RAC
mkdir JT00
cd JT00
for i in {2002..2013};do
    mkdir $i
done

cd /mnt/ide0/home/cmaene/data/LED_OTM/Version71wksp
mkdir WAC
cd WAC
mkdir JT00
cd JT00
for i in {2002..2013};do
    mkdir $i
done

cd /mnt/ide0/home/cmaene/data/LED_OTM/Version71
for i in {2002..2013};do
    find -name '*_rac_S000_JT00_'$i'.csv' -exec cp -t /mnt/ide0/home/cmaene/data/LED_OTM/Version71wksp/RAC/JT00/$i {} +
    find -name '*_wac_S000_JT00_'$i'.csv' -exec cp -t /mnt/ide0/home/cmaene/data/LED_OTM/Version71wksp/WAC/JT00/$i {} +
done

# ---------------------------------------------------------
# Stata - finally format the data files
# ---------------------------------------------------------
# run crledrac0213.do - pre-process files to create annual data files
# run crledwac0213.do - pre-process files to create annual data files
# run crledracwac0213_mergeall.do - aggregate/collapse and merge all by tract & county
# final 4 outputs (tract/county for RAC/WAC): tract10code_led0213.dta, county10code_led0213.dta

# ---------------------------------------------------------
# Stata - clip for 2011-2013 only, what Prof. Allard asked for 
# ---------------------------------------------------------
# run ProfAllard_clip2011-13.do

